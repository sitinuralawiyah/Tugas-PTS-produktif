﻿Public Class Form1
    Dim sqlnya As String
    Dim total As Integer
    Sub panggildata()
        konek()
        DA = New OleDb.OleDbDataAdapter("SELECT * FROM list", conn)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "list")
        DataGridView1.DataSource = DS.Tables("list")
        DataGridView1.Enabled = True
    End Sub
    Sub jalan()
        Dim objcmd As New System.Data.OleDb.OleDbCommand
        Call konek()
        objcmd.Connection = conn
        objcmd.CommandType = CommandType.Text
        objcmd.CommandText = sqlnya
        objcmd.ExecuteNonQuery()
        objcmd.Dispose()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call panggildata()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sqlnya = "insert into list (nama,umur,alamat,tanggal_cek,total_YA) values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "')"
        Call jalan()
        MsgBox("Data Berhasil Tersimpan")
        Call panggildata()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        TextBox1.Text = DataGridView1.Item(0, i).Value
        TextBox2.Text = DataGridView1.Item(1, i).Value
        TextBox4.Text = DataGridView1.Item(2, i).Value
        TextBox5.Text = DataGridView1.Item(3, i).Value
        TextBox6.Text = DataGridView1.Item(4, i).Value
    End Sub
    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        TextBox6.Text = total
        TextBox6.Enabled = False
    End Sub
    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        konek()
        DA = New OleDb.OleDbDataAdapter("SELECT * FROM list where nama like'%" & TextBox3.Text & "%'", conn)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "list")
        DataGridView1.DataSource = DS.Tables("list")
    End Sub
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox7.CheckedChanged
        If CheckBox7.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox8.CheckedChanged
        If CheckBox8.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox9.CheckedChanged
        If CheckBox9.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox10.CheckedChanged
        If CheckBox10.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox11_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox11.CheckedChanged
        If CheckBox11.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox12_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox12.CheckedChanged
        If CheckBox12.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox13_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox13.CheckedChanged
        If CheckBox13.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox14_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox14.CheckedChanged
        If CheckBox14.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox15_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox15.CheckedChanged
        If CheckBox15.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox16_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox16.CheckedChanged
        If CheckBox16.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox17_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox17.CheckedChanged
        If CheckBox17.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox18_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox18.CheckedChanged
        If CheckBox18.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox19_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox19.CheckedChanged
        If CheckBox19.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox20_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox20.CheckedChanged
        If CheckBox20.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If
        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub CheckBox21_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox21.CheckedChanged
        If CheckBox21.Checked = True Then
            total += 1
            TextBox6.Text = total
        Else
            total -= 1
            TextBox6.Text = total
        End If

        If total <= 7 Then
            Panel2.BackColor = Color.Green
        ElseIf total <= 14 Then
            Panel2.BackColor = Color.Blue
        ElseIf total >= 15 Then
            Panel2.BackColor = Color.Red
        End If
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Terimakasih Telah Mencoba Program Ini ^o^")
        End
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Panel2.BackColor = Color.Green
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
        CheckBox5.Checked = False
        CheckBox6.Checked = False
        CheckBox7.Checked = False
        CheckBox8.Checked = False
        CheckBox9.Checked = False
        CheckBox10.Checked = False
        CheckBox11.Checked = False
        CheckBox12.Checked = False
        CheckBox13.Checked = False
        CheckBox14.Checked = False
        CheckBox15.Checked = False
        CheckBox16.Checked = False
        CheckBox17.Checked = False
        CheckBox18.Checked = False
        CheckBox19.Checked = False
        CheckBox20.Checked = False
        CheckBox21.Checked = False
    End Sub
End Class
